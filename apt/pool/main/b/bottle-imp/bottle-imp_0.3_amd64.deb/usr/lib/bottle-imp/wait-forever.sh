#!/bin/sh
while true
do
  sleep 1h
done
